package com.fakex.bitcoin.models.response;

public class JwtResponse {
}

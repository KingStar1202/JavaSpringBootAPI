package com.fakex.bitcoin.models.users;

public enum  ERole {
    ROLE_USER,
    ROLE_MODERATOR,
    ROLE_ADMIN
}

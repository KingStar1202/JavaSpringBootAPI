package com.fakex.bitcoin.controller;

import com.fakex.bitcoin.models.response.ApiResponse;
import com.fakex.bitcoin.models.users.Transaction;
import com.fakex.bitcoin.models.users.TransactionType;
import com.fakex.bitcoin.models.users.User;
import com.fakex.bitcoin.repositories.UserRepository;
import com.fakex.bitcoin.request.DeleteTransactionRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/transaction")
public class TransactionController {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/buy")
    public ResponseEntity<?> addBuy(HttpServletRequest request) {
        //TODO security check if request is valid
        try {
            User user = userRepository.findByEmail(request.getParameter("email")).get();
            Transaction transaction = new Transaction();
            transaction.setTransactionType(TransactionType.BUY);
            transaction.setPricePerUnit(Long.parseLong(request.getParameter("price")));
            transaction.setQuantity(Integer.parseInt(request.getParameter("quantity")));
            transaction.setSymbol(request.getParameter("symbol"));
            user.getWallet().addTransaction(transaction);
            mongoTemplate.save(user);

        } catch (Exception e) {
            return ResponseEntity.status(550).body("not enough money on your account");
        }
        return ResponseEntity.ok(new ApiResponse(true,"Transaction add successfully!"));
    }
    @PostMapping("/sell")
    public ResponseEntity<?> addSell(HttpServletRequest request) {
        //TODO security check if request is valid
        try {
            User user = userRepository.findByEmail(request.getParameter("email")).get();
            Transaction transaction = new Transaction();
            transaction.setTransactionType(TransactionType.SELL);
            transaction.setPricePerUnit(Long.parseLong(request.getParameter("price")));
            transaction.setQuantity(Integer.parseInt(request.getParameter("quantity")));
            transaction.setSymbol(request.getParameter("symbol"));
            user.getWallet().addTransaction(transaction);
            mongoTemplate.save(user);

        } catch (Exception e) {
            return ResponseEntity.status(550).body("not enough money on your account");
        }
        return ResponseEntity.ok(new ApiResponse(true,"Transaction add successfully!"));
    }

    @DeleteMapping("/delete")
    public ResponseEntity<?> deleteTransaction(@RequestBody DeleteTransactionRequest request) {

        User user = userRepository.findByEmail(request.getUserEmail()).get();
        user.getWallet().sellTransaction(request.getTransactionId());
        mongoTemplate.save(user);
        return ResponseEntity.ok("Transaction deleted");
    }


}

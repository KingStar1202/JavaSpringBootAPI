package com.fakex.bitcoin.db;

import org.springframework.context.annotation.Configuration;

@Configuration
public class MongoConf {


}

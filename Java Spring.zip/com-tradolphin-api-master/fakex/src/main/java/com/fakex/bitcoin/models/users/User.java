package com.fakex.bitcoin.models.users;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.bson.types.Binary;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.HashSet;
import java.util.Set;

@RequiredArgsConstructor
@Document(collection = "users")
@Data public class User {

    private String firstname;
    private String lastname;
    @Id
    private String id;
    private String email;
    private String password;

    private Wallet wallet;

    private Binary image;
    @DBRef
    private Set<Role> roles = new HashSet<>();


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    public User(String firstname, String lastname, String email, String password, Wallet wallet) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.email = email;
        this.password = password;
        this.wallet = wallet;
    }
    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }
}

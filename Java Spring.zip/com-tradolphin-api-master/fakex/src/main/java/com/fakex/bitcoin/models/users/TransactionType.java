package com.fakex.bitcoin.models.users;

public enum TransactionType {
    SELL, BUY
}

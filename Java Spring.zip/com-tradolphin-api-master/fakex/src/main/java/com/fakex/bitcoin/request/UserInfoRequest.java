package com.fakex.bitcoin.request;

import lombok.Data;

@Data public class UserInfoRequest {

    private String email;

}

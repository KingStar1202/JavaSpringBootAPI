/* globals Chart:false, feather:false */

(function () {
  "use strict";

  feather.replace();

  // Graphs
  var ctx = document.getElementById("myChart");
  // eslint-disable-next-line no-unused-vars
  var myChart = new Chart(ctx, {
    type: "line",
    data: {
      labels: [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
      ],
      datasets: [
        {
          data: [15339, 21345, 18483, 24003, 23489, 24092, 12034],
          lineTension: 0,
          backgroundColor: "transparent",
          borderColor: "#007bff",
          borderWidth: 4,
          pointBackgroundColor: "#007bff",
        },
      ],
    },
    options: {
      scales: {
        yAxes: [
          {
            ticks: {
              beginAtZero: false,
            },
          },
        ],
      },
      legend: {
        display: false,
      },
    },
  });
})();


$(document).ready(function(){
  $("#buy_fee").val("0");
  $("#sell_fee").val("0");
  $("#btn_buy").click(function(){

    var amount = $("#buy_amount").val();
    var price = $("#buy_price").val();
    if(amount == "" || price==""){
      alert("Insert the Price and Amount Price!!!");
      return;
    }
    if(isNaN(amount) || isNaN(price)){
      alert("Insert the correct style.");
      return;
    }
    var total = parseFloat(amount)*parseFloat(price);
    $("#buy_fee").val("0");
    $("#buy_sum").val(total);
    $("#buy_total").val(total);
    var settings = {
      "url": "http://localhost:8080/transaction/auth/signup",
      "method": "POST",
      "timeout": 0, 
      "data": {
        "email": email,
        "quantity": amount,
        "price": price,
        "symbol": "bicoin"
      }
  };
  $.ajax(settings).done(function (data) {
      if(data.success == true){
          alert(data.message);
          return;
      }else{
          return;
      }
      
    });
  });

  $("#btn_sell").click(function(){

    var amount = $("#sell_amount").val();
    var price = $("#sell_price").val();
    if(amount == "" || price==""){
      alert("Insert the Price and Amount Price!!!");
      return;
    }
    if(isNaN(amount) || isNaN(price)){
      alert("Insert the correct style.");
      return;
    }
    var total = parseFloat(amount)*parseFloat(price);
    $("#sell_fee").val("0");
    $("#sell_sum").val(total);
    $("#sell_total").val(total);
    var settings = {
      "url": "http://localhost:8080/transaction/auth/signup",
      "method": "POST",
      "timeout": 0, 
      "data": {
        "email": email,
        "quantity": amount,
        "price": price,
        "symbol": "bicoin"
      }
  };
  $.ajax(settings).done(function (data) {
      if(data.success == true){
          alert(data.message);
          return;
      }else{
          return;
      }
      
    });
  });
});
$(document).ready(function () {
  var sdk = new SDK("http://localhost:8080");
  sdk.register();
});
